-- HOSPITAL_ODS
IF DB_ID('Hospital_ODS') IS NOT NULL
    DROP DATABASE Hospital_ODS;
GO
CREATE DATABASE Hospital_ODS;
GO
USE Hospital_ODS;
GO

CREATE TABLE ODS_Categoria_Medicamento (
    id_categoria INT PRIMARY KEY,
    nombre VARCHAR(150) NOT NULL,
    descripcion VARCHAR(255),
    fecha_creacion DATETIME,
    estado BIT DEFAULT 1,
    FechaUltimaCarga DATETIME,

);

CREATE TABLE ODS_Proveedor (
    id_proveedor INT PRIMARY KEY,
    nombre VARCHAR(150) NOT NULL,
    ruc CHAR(11),
    telefono VARCHAR(20),
    direccion VARCHAR(255),
    correo VARCHAR(150),
    fecha_registro DATETIME,
    estado BIT DEFAULT 1,
    FechaUltimaCarga DATETIME,
);

CREATE TABLE ODS_Almacen (
    id_almacen INT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    ubicacion VARCHAR(255),
    capacidad INT,
    responsable VARCHAR(150),
    fecha_creacion DATETIME,
    estado BIT DEFAULT 1,
    FechaUltimaCarga DATETIME,
);

CREATE TABLE ODS_Area_Hospitalaria (
    id_area INT PRIMARY KEY,
    nombre VARCHAR(150) NOT NULL,
    piso INT,
    fecha_creacion DATETIME,
    estado BIT DEFAULT 1,
    FechaUltimaCarga DATETIME,
);

CREATE TABLE ODS_JefeArea (
    id_jefearea INT PRIMARY KEY,
    nombre VARCHAR(150) NOT NULL,
    dni CHAR(8),
    telefono VARCHAR(20),
    turno VARCHAR(50),
    cargo VARCHAR(100),
    fecha_registro DATETIME,
    estado BIT DEFAULT 1,
    FechaUltimaCarga DATETIME,
);

CREATE TABLE ODS_Medicamento (
    id_medicamento INT PRIMARY KEY,
    nombre VARCHAR(150) NOT NULL,
    descripcion VARCHAR(255),
    fecha_vencimiento DATE,
    stock INT DEFAULT 0,
    precio DECIMAL(10,2) DEFAULT 0,
    lote VARCHAR(50),
    id_categoria INT,
    fecha_registro DATETIME,
    estado BIT DEFAULT 1,
    FechaUltimaCarga DATETIME,
    CONSTRAINT FK_ODS_Medic_Cat FOREIGN KEY (id_categoria) REFERENCES ODS_Categoria_Medicamento(id_categoria)
);

CREATE TABLE ODS_Compra (
    id_compra INT PRIMARY KEY,
    fecha_compra DATE,
    total DECIMAL(12,2) DEFAULT 0,
    id_jefearea INT,
    metodo_pago VARCHAR(50),
    observaciones VARCHAR(255),
    estado BIT DEFAULT 1,
    fecha_registro DATETIME,
    FechaUltimaCarga DATETIME,
    CONSTRAINT FK_ODS_Compra_Jefe FOREIGN KEY (id_jefearea) REFERENCES ODS_JefeArea(id_jefearea)
);

CREATE TABLE ODS_Medicamento_Compra (
    id_medicamento INT,
    id_compra INT,
    cantidad INT DEFAULT 0,
    subtotal DECIMAL(10,2) DEFAULT 0,
    FechaUltimaCarga DATETIME,
    PRIMARY KEY (id_medicamento, id_compra),
    CONSTRAINT FK_ODS_MC_Med FOREIGN KEY (id_medicamento) REFERENCES ODS_Medicamento(id_medicamento),
    CONSTRAINT FK_ODS_MC_Compra FOREIGN KEY (id_compra) REFERENCES ODS_Compra(id_compra)
);

CREATE TABLE ODS_Medicamento_Almacen (
    id_medicamento INT,
    id_almacen INT,
    cantidad INT DEFAULT 0,
    fecha_ingreso DATE,
    FechaUltimaCarga DATETIME,
    PRIMARY KEY (id_medicamento, id_almacen),
    CONSTRAINT FK_ODS_MA_Med FOREIGN KEY (id_medicamento) REFERENCES ODS_Medicamento(id_medicamento),
    CONSTRAINT FK_ODS_MA_Alm FOREIGN KEY (id_almacen) REFERENCES ODS_Almacen(id_almacen)
);

CREATE TABLE ODS_Medicamento_Proveedor (
    id_medicamento INT NOT NULL,
    id_proveedor INT NOT NULL,
    fecha_distribucion DATE,
    precio_unitario DECIMAL(10,2),
    FechaUltimaCarga DATETIME,
    PRIMARY KEY (id_medicamento, id_proveedor),
    CONSTRAINT FK_ODS_MP_Med FOREIGN KEY (id_medicamento) REFERENCES ODS_Medicamento(id_medicamento),
    CONSTRAINT FK_ODS_MP_Prov FOREIGN KEY (id_proveedor) REFERENCES ODS_Proveedor(id_proveedor)
);


CREATE TABLE ODS_Medicamento_Area (
    id_medicamento INT,
    id_area INT,
    cantidad_disponible INT DEFAULT 0,
    FechaUltimaCarga DATETIME,
    PRIMARY KEY (id_medicamento, id_area),
    CONSTRAINT FK_ODS_MA2_Med FOREIGN KEY (id_medicamento) REFERENCES ODS_Medicamento(id_medicamento),
    CONSTRAINT FK_ODS_MA2_Area FOREIGN KEY (id_area) REFERENCES ODS_Area_Hospitalaria(id_area)
);

DELETE FROM ODS_Medicamento_Compra;
DELETE FROM ODS_Medicamento_Almacen;
DELETE FROM ODS_Medicamento_Area;
DELETE FROM ODS_Medicamento;
DELETE FROM ODS_Compra;
DELETE FROM ODS_Categoria_Medicamento;
DELETE FROM ODS_JefeArea;
DELETE FROM ODS_Almacen;
DELETE FROM ODS_Area_Hospitalaria;
DELETE FROM ODS_Proveedor;
DELETE FROM ODS_Medicamento_Proveedor;
GO