-- ======================================================
--      BASE DE DATOS HOSPITAL
-- ======================================================

CREATE DATABASE Hospital;
GO
USE Hospital;
GO

-- ======================================================
-- 1. CATEGORIA_MEDICAMENTO
-- ======================================================
CREATE TABLE Categoria_Medicamento (
    id_categoria INT IDENTITY(1,1) PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    descripcion VARCHAR(255),
    fecha_creacion DATETIME DEFAULT GETDATE(),
    estado BIT DEFAULT 1
);

-- ======================================================
-- 2. MEDICAMENTO
-- ======================================================
CREATE TABLE Medicamento (
    id_medicamento INT IDENTITY(1,1) PRIMARY KEY,
    nombre VARCHAR(150) NOT NULL,
    descripcion VARCHAR(255),
    fecha_vencimiento DATE NOT NULL,
    stock INT CHECK (stock >= 0),
    precio DECIMAL(10,2) CHECK (precio >= 0),
    lote VARCHAR(50),
    id_categoria INT NOT NULL,
    fecha_registro DATETIME DEFAULT GETDATE(),
    estado BIT DEFAULT 1,
    CONSTRAINT FK_Medic_Cat FOREIGN KEY (id_categoria)
        REFERENCES Categoria_Medicamento(id_categoria)
);

-- ======================================================
-- 3. PROVEEDOR
-- ======================================================
CREATE TABLE Proveedor (
    id_proveedor INT IDENTITY(1,1) PRIMARY KEY,
    nombre VARCHAR(150) NOT NULL,
    ruc CHAR(11) NOT NULL,
    telefono VARCHAR(20),
    direccion VARCHAR(255),
    correo VARCHAR(150),
    fecha_registro DATETIME DEFAULT GETDATE(),
    estado BIT DEFAULT 1
);
use Hospital
SELECT * FROM Proveedor

-- ======================================================
-- 4. ALMACEN
-- ======================================================
CREATE TABLE Almacen (
    id_almacen INT IDENTITY(1,1) PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    ubicacion VARCHAR(255),
    capacidad INT,
    responsable VARCHAR(150),
    fecha_creacion DATETIME DEFAULT GETDATE(),
    estado BIT DEFAULT 1
);

-- ======================================================
-- 5. AREA HOSPITALARIA
-- ======================================================
CREATE TABLE Area_Hospitalaria (
    id_area INT IDENTITY(1,1) PRIMARY KEY,
    nombre VARCHAR(150) NOT NULL,
    piso INT,
    fecha_creacion DATETIME DEFAULT GETDATE(),
    estado BIT DEFAULT 1
);

-- ======================================================
-- 6. JEFEAREA
-- ======================================================
CREATE TABLE JefeArea (
    id_jefearea INT IDENTITY(1,1) PRIMARY KEY,
    nombre VARCHAR(150) NOT NULL,
    dni CHAR(8) NOT NULL,
    telefono VARCHAR(20),
    turno VARCHAR(50),
    cargo VARCHAR(100),
    fecha_registro DATETIME DEFAULT GETDATE(),
    estado BIT DEFAULT 1
);

-- ======================================================
-- 7. COMPRA
-- ======================================================
CREATE TABLE Compra (
    id_compra INT IDENTITY(1,1) PRIMARY KEY,
    fecha_compra DATE NOT NULL,
    total DECIMAL(12,2) CHECK(total >= 0),
    id_jefearea INT NOT NULL,
    metodo_pago VARCHAR(50),
    observaciones VARCHAR(255),
    estado BIT DEFAULT 1,
    fecha_registro DATETIME DEFAULT GETDATE(),
    CONSTRAINT FK_Compra_Jefe FOREIGN KEY (id_jefearea) REFERENCES JefeArea(id_jefearea)
);

-- ======================================================
-- TABLAS RELACIONALES EXACTAS DEL DIAGRAMA
-- ======================================================

-- MEDICAMENTO - PROVEEDOR
CREATE TABLE Medicamento_Proveedor (
    id_medicamento INT NOT NULL,
    id_proveedor INT NOT NULL,
    fecha_distribucion DATE,
    precio_unitario DECIMAL(10,2),
    PRIMARY KEY (id_medicamento, id_proveedor),
    FOREIGN KEY (id_medicamento) REFERENCES Medicamento(id_medicamento),
    FOREIGN KEY (id_proveedor) REFERENCES Proveedor(id_proveedor)
);

-- MEDICAMENTO - ALMACEN
CREATE TABLE Medicamento_Almacen (
    id_medicamento INT NOT NULL,
    id_almacen INT NOT NULL,
    cantidad INT CHECK (cantidad >= 0),
    fecha_ingreso DATE,
    PRIMARY KEY (id_medicamento, id_almacen),
    FOREIGN KEY (id_medicamento) REFERENCES Medicamento(id_medicamento),
    FOREIGN KEY (id_almacen) REFERENCES Almacen(id_almacen)
);

-- MEDICAMENTO - COMPRA
CREATE TABLE Medicamento_Compra (
    id_medicamento INT NOT NULL,
    id_compra INT NOT NULL,
    cantidad INT CHECK (cantidad > 0),
    subtotal DECIMAL(10,2),
    PRIMARY KEY (id_medicamento, id_compra),
    FOREIGN KEY (id_medicamento) REFERENCES Medicamento(id_medicamento),
    FOREIGN KEY (id_compra) REFERENCES Compra(id_compra)
);

-- MEDICAMENTO - AREA
CREATE TABLE Medicamento_Area (
    id_medicamento INT NOT NULL,
    id_area INT NOT NULL,
    cantidad_disponible INT CHECK (cantidad_disponible >= 0),
    PRIMARY KEY (id_medicamento, id_area),
    FOREIGN KEY (id_medicamento) REFERENCES Medicamento(id_medicamento),
    FOREIGN KEY (id_area) REFERENCES Area_Hospitalaria(id_area)
);

-- ======================================================
-- AUDITORIA
-- ======================================================
CREATE TABLE Auditoria (
    id_auditoria INT IDENTITY(1,1) PRIMARY KEY,
    tabla VARCHAR(100) NOT NULL,
    accion VARCHAR(50) NOT NULL,
    usuario VARCHAR(100),
    fecha DATETIME DEFAULT GETDATE(),
    detalle VARCHAR(500)
);
GO

-- ======================================================
-- FUNCIONES
-- ======================================================
-- 1. Total de medicamentos registrados
CREATE FUNCTION fn_TotalMedicamentos()
RETURNS INT
AS
BEGIN
    RETURN (SELECT COUNT(*) FROM Medicamento WHERE estado = 1);
END;
GO

-- 2. Valor total del inventario (stock * precio)
CREATE FUNCTION fn_ValorInventario()
RETURNS DECIMAL(18,2)
AS
BEGIN
    RETURN (
        SELECT SUM(stock * precio)
        FROM Medicamento
        WHERE estado = 1
    );
END;
GO

-- 3. Obtener nombre de categor�a de un medicamento
CREATE FUNCTION fn_CategoriaDeMedicamento(@id_medicamento INT)
RETURNS VARCHAR(100)
AS
BEGIN
    RETURN (
        SELECT c.nombre
        FROM Medicamento m
        INNER JOIN Categoria_Medicamento c
            ON m.id_categoria = c.id_categoria
        WHERE m.id_medicamento = @id_medicamento
    );
END;
GO

-- ======================================================
-- PROCEDURES   
-- ======================================================
CREATE PROCEDURE sp_InsertCategoria
    @nombre VARCHAR(100),
    @descripcion VARCHAR(255)
AS
BEGIN
    INSERT INTO Categoria_Medicamento(nombre, descripcion)
    VALUES(@nombre, @descripcion);
END;
GO

CREATE PROCEDURE sp_UpdateCategoria
    @id_categoria INT,
    @nombre VARCHAR(100),
    @descripcion VARCHAR(255),
    @estado BIT
AS
BEGIN
    UPDATE Categoria_Medicamento
    SET nombre = @nombre,
        descripcion = @descripcion,
        estado = @estado
    WHERE id_categoria = @id_categoria;
END;
GO

CREATE PROCEDURE sp_DeleteCategoria
    @id_categoria INT
AS
BEGIN
    DELETE FROM Categoria_Medicamento
    WHERE id_categoria = @id_categoria;
END;
GO

CREATE PROCEDURE sp_InsertMedicamento
    @nombre VARCHAR(150),
    @descripcion VARCHAR(255),
    @fecha_venc DATE,
    @stock INT,
    @precio DECIMAL(10,2),
    @lote VARCHAR(50),
    @id_categoria INT
AS
BEGIN
    INSERT INTO Medicamento(nombre, descripcion, fecha_vencimiento, stock, precio, lote, id_categoria)
    VALUES(@nombre, @descripcion, @fecha_venc, @stock, @precio, @lote, @id_categoria);
END;
GO

CREATE PROCEDURE sp_UpdateMedicamento
    @id_medicamento INT,
    @nombre VARCHAR(150),
    @descripcion VARCHAR(255),
    @fecha_venc DATE,
    @stock INT,
    @precio DECIMAL(10,2),
    @lote VARCHAR(50),
    @id_categoria INT,
    @estado BIT
AS
BEGIN
    UPDATE Medicamento
    SET nombre=@nombre,
        descripcion=@descripcion,
        fecha_vencimiento=@fecha_venc,
        stock=@stock,
        precio=@precio,
        lote=@lote,
        id_categoria=@id_categoria,
        estado=@estado
    WHERE id_medicamento=@id_medicamento;
END;
GO

CREATE PROCEDURE sp_InsertProveedor
    @nombre VARCHAR(150),
    @ruc CHAR(11),
    @telefono VARCHAR(20),
    @direccion VARCHAR(255),
    @correo VARCHAR(150)
AS
BEGIN
    INSERT INTO Proveedor(nombre, ruc, telefono, direccion, correo)
    VALUES(@nombre, @ruc, @telefono, @direccion, @correo);
END;
GO

CREATE PROCEDURE sp_InsertCompra
    @fecha DATE,
    @id_jefearea INT,
    @metodo_pago VARCHAR(50),
    @observaciones VARCHAR(255)
AS
BEGIN
    INSERT INTO Compra(fecha_compra, total, id_jefearea, metodo_pago, observaciones)
    VALUES(@fecha, 0, @id_jefearea, @metodo_pago, @observaciones);
END;
GO

CREATE PROCEDURE sp_InsertMedicamentoCompra
    @id_compra INT,
    @id_medicamento INT,
    @cantidad INT,
    @precio DECIMAL(10,2)
AS
BEGIN
    INSERT INTO Medicamento_Compra(id_medicamento, id_compra, cantidad, subtotal)
    VALUES(@id_medicamento, @id_compra, @cantidad, @precio * @cantidad);
END;
GO


-- ======================================================
-- TRIGGER
-- ======================================================
CREATE TRIGGER trg_AumentarStock
ON Medicamento_Compra
AFTER INSERT
AS
BEGIN
    UPDATE m
    SET m.stock = m.stock + i.cantidad
    FROM Medicamento m
    INNER JOIN inserted i
        ON m.id_medicamento = i.id_medicamento;
END;
GO

CREATE TRIGGER trg_RecalcularTotalCompra
ON Medicamento_Compra
AFTER INSERT, DELETE
AS
BEGIN
    UPDATE c
    SET c.total = (
        SELECT SUM(subtotal)
        FROM Medicamento_Compra mc
        WHERE mc.id_compra = c.id_compra
    )
    FROM Compra c;
END;
GO

CREATE TRIGGER trg_NoEliminarCategoria
ON Categoria_Medicamento
INSTEAD OF DELETE
AS
BEGIN
    IF EXISTS(
        SELECT 1 FROM Medicamento
        WHERE id_categoria IN (SELECT id_categoria FROM deleted)
    )
    BEGIN
        RAISERROR('No se puede eliminar la categor�a porque tiene medicamentos asociados.', 16, 1);
        RETURN;
    END

    DELETE FROM Categoria_Medicamento
    WHERE id_categoria IN (SELECT id_categoria FROM deleted);
END;
GO

CREATE TRIGGER trg_AuditoriaMedicamento
ON Medicamento
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    DECLARE @accion VARCHAR(50);

    IF EXISTS(SELECT * FROM inserted) AND EXISTS(SELECT * FROM deleted)
        SET @accion = 'UPDATE';
    ELSE IF EXISTS(SELECT * FROM inserted)
        SET @accion = 'INSERT';
    ELSE
        SET @accion = 'DELETE';

    INSERT INTO Auditoria(tabla, accion, usuario, detalle)
    SELECT 
        'Medicamento',
        @accion,
        SUSER_SNAME(),
        'Cambios realizados en la tabla Medicamento'
    FROM inserted;
END;
GO

CREATE TRIGGER trg_AuditoriaCompra
ON Compra
AFTER INSERT, DELETE
AS
BEGIN
    INSERT INTO Auditoria(tabla, accion, usuario, detalle)
    SELECT 
        'Compra',
        CASE 
            WHEN EXISTS(SELECT * FROM inserted) THEN 'INSERT'
            ELSE 'DELETE'
        END,
        SUSER_SNAME(),
        'Movimiento de compra'
    FROM inserted;
END;
GO

CREATE TRIGGER trg_AudProveedor
ON Proveedor
AFTER INSERT
AS
BEGIN
    INSERT INTO Auditoria(tabla, accion, usuario, detalle)
    SELECT 
        'Proveedor',
        'INSERT',
        SUSER_SNAME(),
        'Nuevo proveedor registrado'
    FROM inserted;
END;
GO

CREATE TRIGGER trg_StockBajo
ON Medicamento
AFTER INSERT, UPDATE
AS
BEGIN
    IF EXISTS(
        SELECT 1 FROM inserted WHERE stock < 20
    )
    BEGIN
        INSERT INTO Auditoria(tabla, accion, usuario, detalle)
        VALUES('Medicamento', 'STOCK BAJO', SUSER_SNAME(), 'Stock menor a 20 unidades');
    END
END;
GO

-- ======================================================
-- VISTAS
-- ======================================================

CREATE VIEW vw_Inventario
AS
SELECT 
    m.id_medicamento,
    m.nombre,
    m.stock,
    m.precio,
    (m.stock * m.precio) AS valor_total,
    c.nombre AS categoria
FROM Medicamento m
INNER JOIN Categoria_Medicamento c
    ON m.id_categoria = c.id_categoria;
GO

CREATE VIEW vw_ProximosAVencer
AS
SELECT *
FROM Medicamento
WHERE fecha_vencimiento <= DATEADD(DAY, 30, GETDATE());
GO


-- ======================================================
-- INSERCI�N DE DATOS
-- ======================================================
