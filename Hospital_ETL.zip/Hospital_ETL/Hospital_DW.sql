-----------------------------------------------------------
-- CREA BASE DE DATOS DEL DATA WAREHOUSE
-----------------------------------------------------------
IF DB_ID('Hospital_DW') IS NOT NULL
    DROP DATABASE Hospital_DW;
GO
CREATE DATABASE Hospital_DW;
GO
USE Hospital_DW;
GO

-----------------------------------------------------------
-- DIMENSIONES
-----------------------------------------------------------

-- DimFecha 
CREATE TABLE DimFecha (
    FechaKey INT PRIMARY KEY,        
    Fecha DATE NOT NULL,
    Anio INT,
    Mes INT,
    NombreMes VARCHAR(20),
    Dia INT,
    NombreDia VARCHAR(20),
    Trimestre INT,
    SemanaAnio INT,
    EsFinDeSemana BIT
);

-----------------------------------------------------------
-- DimCategoria
-----------------------------------------------------------
CREATE TABLE DimCategoria (
    DimCategoriaSK INT IDENTITY(1,1) PRIMARY KEY,
    CategoriaNK INT,                  
    Nombre VARCHAR(150),
    Descripcion VARCHAR(255),
    StartDate DATETIME DEFAULT GETDATE(),
);

-----------------------------------------------------------
-- DimProveedor
-----------------------------------------------------------
CREATE TABLE DimProveedor (
    DimProveedorSK INT IDENTITY(1,1) PRIMARY KEY,
    ProveedorNK INT,
    Nombre VARCHAR(150),
    RUC CHAR(11),
    Telefono VARCHAR(20),
    Direccion VARCHAR(255),
    Correo VARCHAR(150),
    StartDate DATETIME DEFAULT GETDATE(),
);

-----------------------------------------------------------
-- DimAlmacen
-----------------------------------------------------------
CREATE TABLE DimAlmacen (
    DimAlmacenSK INT IDENTITY(1,1) PRIMARY KEY,
    AlmacenNK INT,
    Nombre VARCHAR(100),
    Ubicacion VARCHAR(255),
    Capacidad INT,
    Responsable VARCHAR(150),
    StartDate DATETIME DEFAULT GETDATE(),
);

-----------------------------------------------------------
-- DimArea
-----------------------------------------------------------
CREATE TABLE DimArea (
    DimAreaSK INT IDENTITY(1,1) PRIMARY KEY,
    AreaNK INT,
    Nombre VARCHAR(150),
    Piso INT,
    StartDate DATETIME DEFAULT GETDATE(),
);

-----------------------------------------------------------
-- DimJefeArea
-----------------------------------------------------------
CREATE TABLE DimJefeArea (
    DimJefeAreaSK INT IDENTITY(1,1) PRIMARY KEY,
    JefeAreaNK INT,
    Nombre VARCHAR(150),
    DNI CHAR(8),
    Telefono VARCHAR(20),
    Turno VARCHAR(50),
    Cargo VARCHAR(100),
    StartDate DATETIME DEFAULT GETDATE(),
);

-----------------------------------------------------------
-- DimMedicamento
-----------------------------------------------------------
CREATE TABLE DimMedicamento (
    DimMedicamentoSK INT IDENTITY(1,1) PRIMARY KEY,
    MedicamentoNK INT,
    Nombre VARCHAR(150),
    Descripcion VARCHAR(255),
    FechaVencimiento DATE,
    Lote VARCHAR(50),
    PrecioActual DECIMAL(10,2),
    DimCategoriaSK INT NULL,
    StartDate DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (DimCategoriaSK) REFERENCES DimCategoria(DimCategoriaSK)
);

-----------------------------------------------------------
-- TABLAS DE HECHOS
-----------------------------------------------------------

-----------------------------------------------------------
-- FactCompraMedicamento (EVENTO)
-----------------------------------------------------------
CREATE TABLE FactCompraMedicamento (
    FactCompraSK INT IDENTITY(1,1) PRIMARY KEY,
    FechaKey INT NOT NULL,
    DimMedicamentoSK INT NULL,
    DimProveedorSK INT NULL,
    DimAreaSK INT NULL,
    DimJefeAreaSK INT NULL,
    Cantidad INT,
    PrecioUnitario DECIMAL(10,2),
    Subtotal AS (Cantidad * PrecioUnitario),
    TotalCompra DECIMAL(12,2),    -- incluye impuestos si aplica
    StockAumentado INT,
    FechaCarga DATETIME DEFAULT GETDATE(),

    FOREIGN KEY (FechaKey) REFERENCES DimFecha(FechaKey),
    FOREIGN KEY (DimMedicamentoSK) REFERENCES DimMedicamento(DimMedicamentoSK),
    FOREIGN KEY (DimProveedorSK) REFERENCES DimProveedor(DimProveedorSK),
    FOREIGN KEY (DimAreaSK) REFERENCES DimArea(DimAreaSK),
    FOREIGN KEY (DimJefeAreaSK) REFERENCES DimJefeArea(DimJefeAreaSK)
);


-----------------------------------------------------------
-- FactInventario (SNAPSHOT DIARIO)
-----------------------------------------------------------
CREATE TABLE FactInventario (
    FactInventarioSK INT IDENTITY(1,1) PRIMARY KEY,
    FechaKey INT NOT NULL,
    DimMedicamentoSK INT NOT NULL,
    DimAlmacenSK INT NULL,
    Stock INT,
    ValorInventario DECIMAL(18,2),
    FechaCarga DATETIME DEFAULT GETDATE(),

    FOREIGN KEY (FechaKey) REFERENCES DimFecha(FechaKey),
    FOREIGN KEY (DimMedicamentoSK) REFERENCES DimMedicamento(DimMedicamentoSK),
    FOREIGN KEY (DimAlmacenSK) REFERENCES DimAlmacen(DimAlmacenSK)
);

GO

IF OBJECT_ID('FactInventario') IS NOT NULL
    DELETE FROM FactInventario;
GO

IF OBJECT_ID('FactCompraMedicamento') IS NOT NULL
    DELETE FROM FactCompraMedicamento;
GO
-----------------------------------------------------------
-- 2. BORRAR TABLAS DE DIMENSIONES (DIM TABLES)
-----------------------------------------------------------
IF OBJECT_ID('DimMedicamento') IS NOT NULL
    DELETE FROM DimMedicamento;
GO

IF OBJECT_ID('DimJefeArea') IS NOT NULL
    DELETE FROM DimJefeArea;
GO

IF OBJECT_ID('DimArea') IS NOT NULL
    DELETE FROM DimArea;
GO

IF OBJECT_ID('DimAlmacen') IS NOT NULL
    DELETE FROM DimAlmacen;
GO

IF OBJECT_ID('DimProveedor') IS NOT NULL
    DELETE FROM DimProveedor;
GO

IF OBJECT_ID('DimCategoria') IS NOT NULL
    DELETE FROM DimCategoria;
GO

IF OBJECT_ID('DimFecha') IS NOT NULL
    DELETE FROM DimFecha;
GO