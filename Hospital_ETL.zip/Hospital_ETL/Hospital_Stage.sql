-- HOSPITAL_STAGE
IF DB_ID('Hospital_Stage') IS NOT NULL
    DROP DATABASE Hospital_Stage;
GO
CREATE DATABASE Hospital_Stage;
GO
USE Hospital_Stage;

-- Stage: copia 1:1 (sin FKs, sin CHECKs) + metadata
CREATE TABLE STG_Categoria_Medicamento (
    id_categoria INT NULL,
    nombre VARCHAR(100) NULL,
    descripcion VARCHAR(255) NULL,
    fecha_creacion DATETIME NULL,
    estado BIT NULL,
    FechaCarga DATETIME DEFAULT GETDATE(),
);
CREATE TABLE STG_Medicamento (
    id_medicamento INT NULL,
    nombre VARCHAR(150) NULL,
    descripcion VARCHAR(255) NULL,
    fecha_vencimiento DATE NULL,
    stock INT NULL,
    precio DECIMAL(10,2) NULL,
    lote VARCHAR(50) NULL,
    id_categoria INT NULL,
    fecha_registro DATETIME NULL,
    estado BIT NULL,
    FechaCarga DATETIME DEFAULT GETDATE(),
);

CREATE TABLE STG_Proveedor (
    id_proveedor INT NULL,
    nombre VARCHAR(150) NULL,
    ruc CHAR(11) NULL,
    telefono VARCHAR(20) NULL,
    direccion VARCHAR(255) NULL,
    correo VARCHAR(150) NULL,
    fecha_registro DATETIME NULL,
    estado BIT NULL,
    FechaCarga DATETIME DEFAULT GETDATE(),
);

CREATE TABLE STG_Almacen (
    id_almacen INT NULL,
    nombre VARCHAR(100) NULL,
    ubicacion VARCHAR(255) NULL,
    capacidad INT NULL,
    responsable VARCHAR(150) NULL,
    fecha_creacion DATETIME NULL,
    estado BIT NULL,
    FechaCarga DATETIME DEFAULT GETDATE(),
);

CREATE TABLE STG_Area_Hospitalaria (
    id_area INT NULL,
    nombre VARCHAR(150) NULL,
    piso INT NULL,
    fecha_creacion DATETIME NULL,
    estado BIT NULL,
    FechaCarga DATETIME DEFAULT GETDATE(),
);

CREATE TABLE STG_JefeArea (
    id_jefearea INT NULL,
    nombre VARCHAR(150) NULL,
    dni CHAR(8) NULL,
    telefono VARCHAR(20) NULL,
    turno VARCHAR(50) NULL,
    cargo VARCHAR(100) NULL,
    fecha_registro DATETIME NULL,
    estado BIT NULL,
    FechaCarga DATETIME DEFAULT GETDATE(),
);

CREATE TABLE STG_Compra (
    id_compra INT NULL,
    fecha_compra DATE NULL,
    total DECIMAL(12,2) NULL,
    id_jefearea INT NULL,
    metodo_pago VARCHAR(50) NULL,
    observaciones VARCHAR(255) NULL,
    estado BIT NULL,
    fecha_registro DATETIME NULL,
    FechaCarga DATETIME DEFAULT GETDATE(),
);

CREATE TABLE STG_Medicamento_Proveedor (
    id_medicamento INT NULL,
    id_proveedor INT NULL,
    fecha_distribucion DATE NULL,
    precio_unitario DECIMAL(10,2) NULL,
    FechaCarga DATETIME DEFAULT GETDATE(),
);

CREATE TABLE STG_Medicamento_Almacen (
    id_medicamento INT NULL,
    id_almacen INT NULL,
    cantidad INT NULL,
    fecha_ingreso DATE NULL,
    FechaCarga DATETIME DEFAULT GETDATE(),
);

CREATE TABLE STG_Medicamento_Compra (
    id_medicamento INT NULL,
    id_compra INT NULL,
    cantidad INT NULL,
    subtotal DECIMAL(10,2) NULL,
    FechaCarga DATETIME DEFAULT GETDATE(),
);

CREATE TABLE STG_Medicamento_Area (
    id_medicamento INT NULL,
    id_area INT NULL,
    cantidad_disponible INT NULL,
    FechaCarga DATETIME DEFAULT GETDATE(),
);


DELETE FROM STG_Categoria_Medicamento;
DELETE FROM STG_Medicamento;
DELETE FROM STG_Proveedor;
DELETE FROM STG_Almacen;
DELETE FROM STG_Area_Hospitalaria;
DELETE FROM STG_JefeArea;
DELETE FROM STG_Compra;
DELETE FROM STG_Medicamento_Proveedor;
DELETE FROM STG_Medicamento_Almacen;
DELETE FROM STG_Medicamento_Compra;
DELETE FROM STG_Medicamento_Area;
GO
